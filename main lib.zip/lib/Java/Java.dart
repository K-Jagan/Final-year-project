import 'package:flutter/material.dart';
import 'package:demoapp/Java/Compile_Polymorphism.dart';
import 'package:demoapp/Java/Objectandclasses.dart';
import 'package:demoapp/Java/Inheritance.dart';
import 'package:demoapp/Java/Array.dart';
import 'package:demoapp/Java/Abstraction.dart';
import 'package:demoapp/Java/Encapsulation.dart';
import 'package:demoapp/Java/Controlstatements.dart';
import 'package:demoapp/Java/Runtime_Polymorphism.dart';
import 'package:demoapp/Java/Tutorial.dart';
// Import the correct file

class JavaPage extends StatefulWidget {
  @override
  _JavaPageState createState() => _JavaPageState();
}

class _JavaPageState extends State<JavaPage> {
  final List<String> names = [
    'Tutorial',
    'Inheritance',
    'Compile Polymorphism',
    'Runtime Polymorphism'
    'Array',
    'Abstraction',
    'Encapsulation',
    'Control_statements',
    'Objectandclasses',
  ];

  final List<String> imagePaths = [
    'assets/images/image0.jpg',
    'assets/images/image1.jpg',
    'assets/images/image2.jpg',
    'assets/images/image3.jpg',
    'assets/images/image4.jpg',
    'assets/images/image5.jpg',
    'assets/images/image6.jpg',
    'assets/images/image7.jpg',
    'assets/images/image7.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Java Topics'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
          names.length,
              (index) => CardItem(
            name: names[index],
            imagePath: imagePaths[index],
            pageToNavigate: index,
          ),
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final String imagePath;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.imagePath,
    required this.pageToNavigate,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToPage(context, pageToNavigate);
      },
      child: Card(
        margin: EdgeInsets.all(18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              imagePath,
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void navigateToPage(BuildContext context, int pageToNavigate) {
    switch (pageToNavigate) {
      case 0:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Tutorial(),
        ),
      );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Inheritance(),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Compile_Polymorphism(),
          ),
        );
        break;
      case 3:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Array(),
          ),
        );
        break;
      case 4:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Abstraction(),
          ),
        );
        break;
      case 5:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Encapsulation(),
          ),
        );
        break;
      case 6:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Controlstatements(),
          ),
        );
        break;
      case 7:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Objectandclasses(),
          ),
        );
        break;
      case 7:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Runtime_Polymorphism(),
          ),
        );
        break;
    }
  }
}
