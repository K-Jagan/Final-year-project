import 'package:flutter/material.dart';
import 'package:demoapp/OOPS/Introduction.dart';
import 'package:demoapp/theme/color.dart';

class Template extends StatefulWidget {
  const Template({Key? key});

  @override
  State<Template> createState() => _TemplateState();
}

class _TemplateState extends State<Template> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(90.0),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: AppBar(
              leading: Builder(
                builder: (context) => InkWell(
                  child: Icon(Icons.menu),
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                ),
              ),
              title: const Text("Introduction"),
              titleSpacing: 0.0,
              centerTitle: true,
              toolbarHeight: 60.0,
              toolbarOpacity: 0.8,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(30),
                  topLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                  bottomLeft: Radius.circular(30),
                ),
              ),
              elevation: 1.0,
              shadowColor: Colors.grey,
              backgroundColor: Colors.white,
            ),
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: 2,
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const Introduction()),
              );
            },
            child: CardItem(
              name: index == 0 ? 'Content' : 'YT',
              imagePath: index == 0 ? 'assets/images/introduction_image.jpg' : 'assets/images/yt_image.jpg',
              pageToNavigate: index,
            ),
          );
        },
      ),
      drawer: buildMenu(context),
    );
  }

  Widget buildMenu(BuildContext context) {
    return Drawer(
      child: Container(
        color: AppColor.primary1,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              color: AppColor.primary1,
              height: 250,
              child: DrawerHeader(
                decoration: BoxDecoration(
                  color: AppColor.primary1,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Positioned(
                      top: 20,
                      right: 14,
                      child: Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.blue, width: 3),
                          shape: BoxShape.circle,
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 3,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/icon0.png',
                            fit: BoxFit.cover,
                            height: 25,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Text(
                      'Introduction',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 15),
                  ],
                ),
              ),
            ),
            buildMenuItem('Inheritance', () {
              Navigator.pop(context); // Close the drawer
              // Navigate to Inheritance page
            }),
            buildMenuItem('Encapsulation', () {
              Navigator.pop(context); // Close the drawer
              // Navigate to Encapsulation page
            }),
            buildMenuItem('Polymorphism1', () {
              Navigator.pop(context); // Close the drawer
              // Navigate to Compile_Polymorphism page
            }),
            buildMenuItem('polymorphism2', () {
              Navigator.pop(context); // Close the drawer
              // Navigate to Runtime_Polymorphism page
            }),
            buildMenuItem('ClassandObject', () {
              Navigator.pop(context); // Close the drawer
              // Navigate to ClassandObject page
            }),
            buildMenuItem('Data Abstraction', () {
              Navigator.pop(context); // Close the drawer
              // Navigate to Data_Abstraction page
            }),
          ],
        ),
      ),
    );
  }

  Widget buildMenuItem(String title, VoidCallback onTap) {
    return Card(
      elevation: 1, // Add elevation for shadow effect
      color: Colors.white,
      shadowColor: Colors.grey.withOpacity(0.9), // Customize shadow color
      margin: EdgeInsets.fromLTRB(25, 15, 0, 15), // Add margin for spacing
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          bottomLeft: Radius.circular(30),
        ),
      ),
      child: ListTile(
        title: Center(child: Text(title)),
        onTap: onTap,
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final String imagePath;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.imagePath,
    required this.pageToNavigate,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Handle tap on card item
      },
      child: Card(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              imagePath,
              width: 100,
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 8),
            Text(
              name,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
