import 'package:flutter/material.dart';
import 'package:demoapp/OperatingSystem/Tutorial.dart';
import 'package:demoapp/OperatingSystem/ProcessManagement.dart';
import 'package:demoapp/OperatingSystem/Synchronization.dart';
import 'package:demoapp/OperatingSystem/Deadlocks.dart';
import 'package:demoapp/OperatingSystem/MemoryManagement.dart';
import 'package:demoapp/OperatingSystem/FileManagement.dart';
import 'package:demoapp/OperatingSystem/Misc.dart';


class OperatingSystemPage extends StatelessWidget {
  final List<String> names = [
    'Tutorial',
    'ProcessManagement',
    'FileManagement',
    'MemoryManagement',
    'Misc',
    'Synchronization',
    'Deadlocks',
  ];
  final List<String> imagePaths = [
    'assets/images/image0.jpg',
    'assets/images/image1.jpg',
    'assets/images/image2.jpg',
    'assets/images/image3.jpg',
    'assets/images/image4.jpg',
    'assets/images/image5.jpg',
    'assets/images/image6.jpg', // Corrected the duplicated image path
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Operating System Topics'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
          names.length,
              (index) => CardItem(
            name: names[index],
            imagePath: imagePaths[index],
            pageToNavigate: index,
          ),
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final String imagePath;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.imagePath,
    required this.pageToNavigate,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToPage(context, pageToNavigate);
      },
      child: Card(
        margin: EdgeInsets.all(18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              imagePath,
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void navigateToPage(BuildContext context, int pageToNavigate) {
    switch (pageToNavigate) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Tutorial(),
          ),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProcessManagement(),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => FileManagement(),
          ),
        );
        break;
      case 3:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => MemoryManagement(),
          ),
        );
        break;
      case 4:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Deadlocks(),
          ),
        );
        break;
      case 5:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Misc(),
          ),
        );
        break;
      case 6:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Synchronization(),
          ),
        );
        break;
    }
  }
}
