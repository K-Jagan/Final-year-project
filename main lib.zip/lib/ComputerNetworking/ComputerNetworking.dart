import 'package:flutter/material.dart';
import 'package:demoapp/ComputerNetworking/IPAddressing.dart';
import 'package:demoapp/ComputerNetworking/NetworkTopology.dart';
import 'package:demoapp/ComputerNetworking/OSIModel.dart';
import 'package:demoapp/ComputerNetworking/Protocols.dart';
import 'package:demoapp/ComputerNetworking/Routing.dart';
import 'package:demoapp/ComputerNetworking/TCP_IPModel.dart';
import 'package:demoapp/ComputerNetworking/Tutorial.dart';



class ComputerNetworkingPage extends StatelessWidget {
  final List<String> names = [
    'Tutorial',
    'NetworkTopology',
    'OSIModel',
    'TCP_IPModel',
    'Protocols',
    'IPAddressing',
    'Routing',
  ];
  final List<String> imagePaths = [
    'assets/images/image0.jpg',
    'assets/images/image1.jpg',
    'assets/images/image2.jpg',
    'assets/images/image3.jpg',
    'assets/images/image4.jpg',
    'assets/images/image5.jpg',
    'assets/images/image6.jpg', // Corrected the duplicated image path
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Computer Networking Topics'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
          names.length,
              (index) => CardItem(
            name: names[index],
            imagePath: imagePaths[index],
            pageToNavigate: index,
          ),
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final String imagePath;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.imagePath,
    required this.pageToNavigate,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToPage(context, pageToNavigate);
      },
      child: Card(
        margin: EdgeInsets.all(18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              imagePath,
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void navigateToPage(BuildContext context, int pageToNavigate) {
    switch (pageToNavigate) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Tutorial(),
          ),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => IPAddressing(),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NetworkTopology(),
          ),
        );
        break;
      case 3:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OSIModel(),
          ),
        );
        break;
      case 4:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Protocols(),
          ),
        );
        break;
      case 5:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Routing(),
          ),
        );
        break;
      case 6:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => TCP_IPModel(),
          ),
        );
        break;
    }
  }
}
