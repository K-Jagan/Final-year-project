import 'package:flutter/material.dart';

class CompletedPage extends StatefulWidget {
  final List<String> selectedAnswers;
  final List<String> correctAnswers;
  final int score;
  final int totalQuestions;

  const CompletedPage({
    Key? key,
    required this.selectedAnswers,
    required this.correctAnswers,
    required this.score,
    required this.totalQuestions,
  }) : super(key: key);

  @override
  State<CompletedPage> createState() => _CompletedPageState();
}

class _CompletedPageState extends State<CompletedPage> {
  @override
  Widget build(BuildContext context) {
    int totalQuestions = widget.correctAnswers.length;
    int correctAnswers = 0;
    int wrongAnswers = 0;

    // Calculate correct and wrong answers
    for (int i = 0; i < totalQuestions; i++) {
      if (widget.selectedAnswers[i] == widget.correctAnswers[i]) {
        correctAnswers++;
      } else {
        wrongAnswers++;
      }
    }

    double completionPercentage = (correctAnswers / totalQuestions) * 100;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Your existing score visualization
            // ...

            // Dynamic completion, total questions, correct, and wrong answers
            SizedBox(
              height: 190,
              width: 320,
              child: Positioned(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 5,
                        spreadRadius: 3,
                        color: const Color(0xffA42FC1).withOpacity(.7),
                        offset: const Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              buildStat('Completion', completionPercentage.toStringAsFixed(0) + '%'),
                              buildStat('Total Questions', totalQuestions.toString()),
                            ],
                          ),
                          const SizedBox(height: 25),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              buildStat('Correct', correctAnswers.toString()),
                              buildStat('Wrong', wrongAnswers.toString()),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Your existing action buttons
            // ...
          ],
        ),
      ),
    );
  }

  Widget buildStat(String title, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              height: 15,
              width: 15,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.green, // You can customize color based on correct/wrong
              ),
            ),
            Text(
              ' $value',
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 20,
                color: Colors.green, // You can customize color based on correct/wrong
              ),
            ),
          ],
        ),
        Text(title),
      ],
    );
  }
}
