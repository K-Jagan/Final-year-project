// HomePage.dart

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Options.dart';
import 'CompletedPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> responseData = [];
  int number = 0;
  List<String> shuffledOptions = [];
  late Timer _timer;
  int _secondsRemaining = 15;
  int score = 0;

  @override
  void initState() {
    super.initState();
    api();
    startTimer();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  Future<void> api() async {
    final response =
    await http.get(Uri.parse('https://opentdb.com/api.php?amount=10'));
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body)['results'] as List;
      setState(() {
        responseData = List<Map<String, dynamic>>.from(data);
        updateShuffleOption();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: SizedBox(
                  height: 421,
                  width: 400,
                  child: Stack(
                    children: [
                      Container(
                        height: 240,
                        width: 390,
                        decoration: BoxDecoration(
                          color: const Color(0xffA42FC1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      Positioned(
                        bottom: 60,
                        left: (400 - 350) / 2,
                        child: Container(
                          height: 170,
                          width: 350,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                offset: const Offset(0, 1),
                                blurRadius: 5,
                                spreadRadius: 3,
                                color: const Color(0xffA42FC1).withOpacity(.4),
                              )
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 18),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '$_secondsRemaining',
                                      style: const TextStyle(
                                        color: Colors.green,
                                        fontSize: 20,
                                      ),
                                    ),
                                  ],
                                ),
                                Center(
                                  child: Text(
                                    "Question ${number + 1}/${responseData.length}",
                                    style: const TextStyle(
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 25,
                                ),
                                Text(
                                  responseData.isNotEmpty
                                      ? responseData[number]['question'] ?? ''
                                      : '',
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 210,
                        left: (400 - 84) / 2,
                        child: CircleAvatar(
                          radius: 42,
                          backgroundColor: Colors.white,
                          child: Center(
                            child: Text(
                              _secondsRemaining.toString(),
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 25,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 1,
            ),
            Column(
              children: [
                if (responseData.isNotEmpty &&
                    responseData[number]['incorrect_answers'] != null)
                  ...shuffledOptions.map(
                        (option) => Options(
                      option: option,
                      correctAnswer: responseData[number]['correct_answer'],
                      onSelected: (isCorrect) {
                        if (isCorrect) {
                          setState(() {
                            score++;
                          });
                        }
                      },
                    ),
                  )
                else
                  const Text('No options available'),
              ],
            ),
            const SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xffA42FC1),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 15,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 5,
                ),
                onPressed: () {
                  nextQuestion();
                },
                child: Container(
                  alignment: Alignment.center,
                  child: const Text(
                    'Next',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void nextQuestion() {
    _timer.cancel();
    if (number < responseData.length - 1) {
      setState(() {
        number++;
        updateShuffleOption();
        _secondsRemaining = 15;
      });
      startTimer();
    } else {
      List<String> selectedAnswersList = []; // Populate this list with actual selected answers
      List<String> correctAnswersList = []; // Populate this list with actual correct answers
      for (int i = 0; i < responseData.length; i++) {
        String selectedAnswer = ""; // Get the selected answer for question i
        selectedAnswersList.add(selectedAnswer);

        String correctAnswer = responseData[i]['correct_answer'];
        correctAnswersList.add(correctAnswer);
      }

      // Access score and responseData.length through class properties
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => CompletedPage(
            selectedAnswers: selectedAnswersList,
            correctAnswers: correctAnswersList,
            score: score,
            totalQuestions: responseData.length,
          ),
        ),
      );
    }
  }




  void updateShuffleOption() {
    setState(() {
      if (responseData.isNotEmpty &&
          responseData[number]['incorrect_answers'] != null) {
        shuffledOptions = shuffleOption([
          responseData[number]['correct_answer'],
          ...(responseData[number]['incorrect_answers'] as List)
        ]);
      }
    });
  }

  List<String> shuffleOption(List<String> option) {
    List<String> shuffledOptions = List.from(option);
    shuffledOptions.shuffle();
    return shuffledOptions;
  }

  void startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_secondsRemaining > 0) {
          _secondsRemaining--;
        } else {
          _secondsRemaining = 15;
          nextQuestion();
        }
      });
    });
  }
}
