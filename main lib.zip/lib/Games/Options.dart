// Options.dart

import 'package:flutter/material.dart';

class Options extends StatelessWidget {
  final String option;
  final String? correctAnswer; // Change made here
  final void Function(bool) onSelected;

  const Options({
    Key? key,
    required this.option,
    required this.correctAnswer,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 58,
          width: 340,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            border: Border.all(width: 3, color: const Color(0xffA42FC1)),
          ),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    option,
                    style: const TextStyle(fontWeight: FontWeight.bold, overflow: TextOverflow.clip),
                  ),
                  Radio(
                    value: option,
                    groupValue: correctAnswer, // Corrected usage here
                    onChanged: (val) {
                      onSelected(val == correctAnswer); // Modified here to check correctness
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        SizedBox(
          height: 10,
        )
      ],
    );
  }
}
