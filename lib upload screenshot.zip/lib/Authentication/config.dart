final url = "http://192.168.29.43:3000/";
final register = url + "registration";
final login = url + "login";
final classobj = url + "oops/classobj/";
final coding = classobj + "coding";
