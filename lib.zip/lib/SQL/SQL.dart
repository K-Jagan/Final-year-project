import 'package:flutter/material.dart';
import 'package:online_course/SQL/AggregateFunctions.dart';
import 'package:online_course/SQL/Clauses.dart';
import 'package:online_course/SQL/CreateDatabase.dart';
import 'package:online_course/SQL/DataConstraints.dart';
import 'package:online_course/SQL/Functions.dart';
import 'package:online_course/SQL/Indexes.dart';
import 'package:online_course/SQL/JoiningData.dart';
import 'package:online_course/SQL/Operators.dart';
import 'package:online_course/SQL/Queries.dart';
import 'package:online_course/SQL/SQLBasics.dart';
import 'package:online_course/SQL/Tables.dart';
import 'package:online_course/SQL/Views.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SQL Topics',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SQLPage(),
    );
  }
}

class SQLPage extends StatelessWidget {
  final List<String> names = [
    'SQL Basics',
    'Create Database in SQL',
    'SQL Tables',
    'SQL Queries',
    'SQL Clauses',
    'SQL Operators',
    'SQL Aggregate Functions',
    'SQL Data Constraints',
    'SQL JoiningData',
    'SQL Functions',
    'SQL Views',
    'SQL Indexes',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SQL Topics'),
      ),
      body: ListView.builder(
        itemCount: names.length,
        itemBuilder: (context, index) => CardItem(
          name: names[index],
          pageToNavigate: index,
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.pageToNavigate,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToPage(context, pageToNavigate);
      },
      child: Card(
        margin: EdgeInsets.all(18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  void navigateToPage(BuildContext context, int pageToNavigate) {
    Widget destinationPage;

    switch (pageToNavigate) {
      case 0:
        destinationPage = SQLBasics();
        break;
      case 1:
        destinationPage = AggregateFunctions();
        break;
      case 2:
        destinationPage = Clauses();
        break;
      case 3:
        destinationPage = CreateDatabase();
        break;
      case 4:
        destinationPage = DataConstraints();
        break;
      case 5:
        destinationPage = Functions();
        break;
      case 7:
        destinationPage = Indexes();
        break;
      case 8:
        destinationPage = JoiningData();
        break;
      case 9:
        destinationPage = Operators();
        break;
      case 10:
        destinationPage = Queries();
        break;
      case 11:
        destinationPage = Tables();
        break;
      case 12:
        destinationPage = Views();
        break;
      default:
        destinationPage = SQLPage();
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => destinationPage,
      ),
    );
  }
}
