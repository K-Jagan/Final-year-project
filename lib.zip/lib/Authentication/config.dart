final url = "http://192.168.29.43:3000/";
final register = url + "registration";
final login = url + "login";
final classobj = url + "oops/classobj";
final inheritance = url + "oops/inheritance";
final abstraction = url + "oops/abstraction";
final encapsulation = url + "oops/encapsulation";

final speech = url + "oops/speech";
final answer = url + "oops/answer";

final coding = url + "oops/classobj/coding";
final putimg = url + "/uploadImage";
final getimg = url + "/getImage'";