import 'package:flutter/material.dart';
import 'package:online_course/OOPS/ClassandObject.dart';
import 'package:online_course/OOPS/Compile_Polymorphism.dart';
import 'package:online_course/OOPS/Data_Abstraction.dart';
import 'package:online_course/OOPS/Encapsulation.dart';
import 'package:online_course/OOPS/Introduction.dart';
import 'package:online_course/OOPS/Inheritance.dart';
import 'package:online_course/OOPS/Runtime_Polymorphism.dart';

class OopPage extends StatefulWidget {
  @override
  _OopPageState createState() => _OopPageState();
}

class _OopPageState extends State<OopPage> {
  final List<String> names = [
    'Introduction',
    'Inheritance',
    'Compile Polymorphism',
    'Run Polymorphism',
    'Data Abstraction',
    'Encapsulation',
    'ClassandObject',
  ];

  final List<String> imagePaths = [
    'assets/images/image0.jpg',
    'assets/images/image1.jpg',
    'assets/images/image2.jpg',
    'assets/images/image3.jpg',
    'assets/images/image4.jpg',
    'assets/images/image5.jpg',
    'assets/images/image6.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('OOP Topics'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
          names.length,
              (index) => CardItem(
            name: names[index],
            imagePath: imagePaths[index],
            pageToNavigate: index,
          ),
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final String imagePath;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.imagePath,
    required this.pageToNavigate,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToPage(context, pageToNavigate);
      },
      child: Card(
        margin: EdgeInsets.all(18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              imagePath,
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void navigateToPage(BuildContext context, int pageToNavigate) {
    switch (pageToNavigate) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Introduction(),
          ),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Inheritance(),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Compile_Polymorphism(),
          ),
        );
        break;
      case 3:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Runtime_Polymorphism(),
          ),
        );
        break;
      case 4:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Data_Abstraction(),
          ),
        );
        break;
      case 5:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Encapsulation(),
          ),
        );
        break;
      case 6:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ClassandObject(),
          ),
        );
        break;
    }
  }
}

class DataAbstractionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(90.0),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: AppBar(
              title: const Text("Data Abstraction"),
              titleSpacing: 0.0,
              centerTitle: true,
              toolbarHeight: 60.0,
              toolbarOpacity: 0.8,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(30),
                  topLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                  bottomLeft: Radius.circular(30),
                ),
              ),
              elevation: 1.0,
              shadowColor: Colors.grey,
              backgroundColor: Colors.white,
            ),
          ),
        ),
      ),
      // Add the content for Data Abstraction page here
      body: Center(
        child: Text("Data Abstraction Content Goes Here"),
      ),
    );
  }
}

// Other classes (Introduction, Inheritance, etc.) remain unchanged.
