import 'package:flutter/material.dart';
import 'package:online_course/DSA/Array.dart';
import 'package:online_course/DSA/Graph.dart';
import 'package:online_course/DSA/Hashing.dart';
import 'package:online_course/DSA/Heap.dart';
import 'package:online_course/DSA/LinkedList.dart';
import 'package:online_course/DSA/Matrix.dart';
import 'package:online_course/DSA/Queue.dart';
import 'package:online_course/DSA/StringDSA.dart';
import 'package:online_course/DSA/Tree.dart';
import 'package:online_course/DSA/Tutorial.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DSA Topics',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: DSAPage(),
    );
  }
}

class DSAPage extends StatelessWidget {
  final List<String> names = [
    'Tutorial',
    'Array',
    'String',
    'LinkedList',
    'Stack',
    'Queue',
    'Tree',
    'Heap',
    'Hashing',
    'Graph',
    'Matrix',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('DSA Topics'),
      ),
      body: ListView.builder(
        itemCount: names.length,
        itemBuilder: (context, index) => CardItem(
          name: names[index],
          pageToNavigate: index,
        ),
      ),
    );
  }
}

class CardItem extends StatelessWidget {
  final String name;
  final int pageToNavigate;

  const CardItem({
    required this.name,
    required this.pageToNavigate,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToPage(context, pageToNavigate);
      },
      child: Card(
        margin: EdgeInsets.all(18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Text(
              '$name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  void navigateToPage(BuildContext context, int pageToNavigate) {
    Widget destinationPage;

    switch (pageToNavigate) {
      case 0:
        destinationPage = Graph();
        break;
      case 1:
        destinationPage = Array();
        break;
      case 2:
        destinationPage = Hashing();
        break;
      case 3:
        destinationPage = Heap();
        break;
      case 4:
        destinationPage = LinkedList();
        break;
      case 7:
        destinationPage = Matrix();
        break;
      case 8:
        destinationPage = Queue();
        break;
      case 9:
        destinationPage = StringDSA(children: [],);
        break;
      case 10:
        destinationPage = Tree(children: [],);
        break;
      case 11:
        destinationPage = Tutorial();
        break;
      default:
        destinationPage = DSAPage();
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => destinationPage,
      ),
    );
  }
}
