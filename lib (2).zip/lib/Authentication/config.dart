final url =  "http://192.168.29.43:3000/";

//Authentiction

final register = url + "registration";
final login = url + "login";

//OOPS

final classobj = url + "oops/classobj";
final inheritance = url + "oops/inheritance";
final abstraction = url + "oops/abstraction";
final encapsulation = url + "oops/encapsulation";
final speech = url + "oops/speech";
final answer = url + "answer";

//JAVA

final encapsulation1 = url + "java/encapsulation";
final object1 = url + "java/object1";
final inheritance1 = url + "java/inheritance";

//Image Logic
final putimg = url + "/uploadImage";
final getimg = url + "/getImage";